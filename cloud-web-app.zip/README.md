# 🌐 Cloud Web App

This is a simple cloud-ready web app built with Flask for the backend and HTML/CSS/JS for the frontend. Designed for easy deployment to cloud platforms like AWS, Heroku, or DigitalOcean.

## 🚀 Features
- Flask backend
- Responsive frontend
- Easy to deploy on any cloud VM

## 🔧 Setup
```bash
pip install -r requirements.txt
python app.py
```

## 📁 Folder Structure
- `app.py` – main application
- `templates/` – HTML files
- `static/` – CSS & JS
