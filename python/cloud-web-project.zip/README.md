# 🌐 Cloud Web App

![App Preview](images/cloud-preview.png)

Welcome to the cloud-ready web application. This project uses Flask for the backend and is designed to be deployed on any cloud platform.

## 📁 Folder Structure
```
cloud-web-project/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── script.js
├── images/
│   └── cloud-preview.png
└── docs/
    └── markdown-style-guide.md
```
