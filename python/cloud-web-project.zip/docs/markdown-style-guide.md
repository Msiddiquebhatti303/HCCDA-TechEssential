# 📘 Markdown Style Guide

## Bold
**This is bold text**

## Italic
*This is italic text*

## Lists
- Item 1
  - Subitem A
  - Subitem B

## Code
`print("Hello World")`

## Image
![Sample](../images/cloud-preview.png)
